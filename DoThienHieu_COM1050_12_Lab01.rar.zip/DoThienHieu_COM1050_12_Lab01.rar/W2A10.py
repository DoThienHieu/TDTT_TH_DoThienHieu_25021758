a = input().split()[::-1]
print(f"Hi {a[0]} {a[1]} and {a[2]}.")