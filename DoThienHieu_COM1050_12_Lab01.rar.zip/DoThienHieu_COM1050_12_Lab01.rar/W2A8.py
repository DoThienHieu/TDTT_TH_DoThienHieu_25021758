a = float(input("nhập độ C: "))
F = 1.8 * a + 32
print("Độ Fahrenheit = {:.2f}".format(F))