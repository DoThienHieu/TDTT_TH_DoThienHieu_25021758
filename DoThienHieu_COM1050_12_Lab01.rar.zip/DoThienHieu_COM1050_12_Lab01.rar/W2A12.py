n = int(input("đỘ dài cạnh: "))
s = n ** 2 * 6
print("số miếng dán", s)