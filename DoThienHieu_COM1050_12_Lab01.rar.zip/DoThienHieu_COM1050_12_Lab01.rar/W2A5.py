h = input("nhập 2 số nguyên a và b: ").split()
a, b = map(int, h)
kq = a ** b
print("kết quả =", kq)
