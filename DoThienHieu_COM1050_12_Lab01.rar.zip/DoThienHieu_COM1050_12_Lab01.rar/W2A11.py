a = int(input("Nhập số giờ: "))
b = int(input("Nhập số phút: "))
h = a * 3600
m = b * 60
print(h, "/h và", m, "/m")
