x = float(input("giá đồng hồ trên Amazon: "))
T = x * 1.4 + 10
print("giá chiếc đồng hồ thực tế khi về Việt Nam: {:.2f}".format(T))