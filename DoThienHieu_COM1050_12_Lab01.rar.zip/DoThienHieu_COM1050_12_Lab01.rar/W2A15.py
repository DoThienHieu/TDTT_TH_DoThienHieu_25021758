n = int(input("Nhập số nguyên dương n:"))
print("Số sao thứ n là:", 3 * n * (n - 1) + 1)