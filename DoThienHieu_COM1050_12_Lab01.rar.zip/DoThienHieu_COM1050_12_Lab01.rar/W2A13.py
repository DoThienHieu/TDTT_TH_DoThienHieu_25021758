a = int(input("Nhập số nguyên dương a: "))
b = int(input("Nhập số nguyên dương b: "))
s = (a * b) % 10
print("hàng đơn vị của phép tính tích giữa a và b là: ", s)