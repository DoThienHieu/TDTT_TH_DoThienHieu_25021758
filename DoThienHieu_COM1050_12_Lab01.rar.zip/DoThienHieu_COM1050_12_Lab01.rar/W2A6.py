h = input("nhập 1 chữ cái thường từ a-z: ")
print("mã unicode:", ord(h))
print("chữ in hoa:", chr(ord(h) - 32))