A = ((13 ** 2) * 3) + 5
B = 13**2*3 + 5
print("A=", A)
print("B=", B)