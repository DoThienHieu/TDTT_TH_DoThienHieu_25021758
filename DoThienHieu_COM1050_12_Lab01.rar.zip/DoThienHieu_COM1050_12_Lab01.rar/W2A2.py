Tên = input("")
print("Xin chào", Tên)