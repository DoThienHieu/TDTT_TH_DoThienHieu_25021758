TDTT =[ "###   # #      ###  ###",  
        " #    #    #    #    #",  
        " #    #     #   #    #",  
        " #    #    #    #    #",  
        " #    # #       #    #",] 

for line in TDTT:
    print(line)
 